<section class="title">
	<?php if(isset($template['title'])) { echo '<h4>'.$template['title'].'</h4>'; } ?>
</section>

<section class="item">
	<?php echo $content; ?>
</section>